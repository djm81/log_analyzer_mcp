# src/log_analyzer_client/__init__.py
