# src/log_analyzer_mcp/core/__init__.py
