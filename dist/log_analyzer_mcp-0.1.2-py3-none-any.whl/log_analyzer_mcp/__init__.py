__version__ = "0.1.1"

# This file makes Python treat the directory as a package.
# It can also be used to expose parts of the package's API.

# from .core.analysis_engine import AnalysisEngine
# from .test_log_parser import parse_test_log_summary # Example if we add such a function
