# This file makes Python treat the directory log_analyzer_mcp as a package.
# It can be empty. 